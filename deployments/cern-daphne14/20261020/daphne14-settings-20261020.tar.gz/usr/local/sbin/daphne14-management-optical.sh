#!/bin/sh
set -eu
test "$(cat /sys/class/net/end0/address)" = 'ba:be:ba:d1:cb:ff'
config=$(devmem 0xff0b0004 32)
devmem 0xff0b0004 32 "$(printf '0x%08x' "$((config & ~0x08000000))")"
devmem 0xff0b0210 32 0x00000020
devmem 0xff0b0200 32 0x00001340
