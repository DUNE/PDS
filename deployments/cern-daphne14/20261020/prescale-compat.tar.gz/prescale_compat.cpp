// Isolated v1.6.0 compatibility interposer; loaded only by this test session.
/**
 * @file TAMakerPrescaleAlgorithm.cpp
 *
 * This is part of the DUNE DAQ Application Framework, copyright 2020.
 * Licensing/copyright details are in the COPYING file that you should have
 * received with this code.
 */

#include "triggeralgs/Prescale/TAMakerPrescaleAlgorithm.hpp"

#include "TRACE/trace.h"
#define TRACE_NAME "TAMakerPrescaleAlgorithm"

#include <vector>
#include <stdexcept>
#include <limits>

using namespace triggeralgs;

using Logging::TLVL_DEBUG_MEDIUM;
using Logging::TLVL_IMPORTANT;

void
TAMakerPrescaleAlgorithm::process(const TriggerPrimitive& input_tp, std::vector<TriggerActivity>& output_ta)
{
  std::vector<TriggerPrimitive> tp_list;
  tp_list.push_back(input_tp);

  // The board under test has detid 8 (VD Cathode PDS). TP v2 has no type field.
  // PDS descriptors use one 62.5-MHz tick per ADC sample. Preserve the
  // installed v1.6.0 TPC behavior for every non-PDS input.
  const bool pds = input_tp.detid == 8;
  const uint64_t sample_ticks = pds ? 1 : 32;
  if (pds && (!input_tp.samples_over_threshold ||
              input_tp.samples_to_peak >= input_tp.samples_over_threshold ||
              input_tp.time_start > std::numeric_limits<uint64_t>::max() - input_tp.samples_over_threshold)) {
    throw std::invalid_argument("Invalid PDS prescale input duration or timestamp");
  }
  TriggerActivity ta;
  ta.time_start = input_tp.time_start;
  ta.time_end = input_tp.time_start + input_tp.samples_over_threshold * sample_ticks;  // FIXME: Replace the hard-coded SOT to TOT scaling.
  ta.time_peak = input_tp.samples_to_peak * sample_ticks + input_tp.time_start;  // FIXME: Replace STP to `time_peak` conversion.
  ta.time_activity = pds ? input_tp.time_start : 0;
  ta.channel_start = input_tp.channel;
  ta.channel_end = input_tp.channel;
  ta.channel_peak = input_tp.channel;
  ta.adc_integral = input_tp.adc_integral;
  ta.adc_peak = input_tp.adc_peak;
  ta.detid = input_tp.detid;
  ta.type = pds ? TriggerActivity::Type::kPDS : TriggerActivity::Type::kTPC;
  ta.algorithm = TriggerActivity::Algorithm::kPrescale;

  ta.inputs = tp_list;

  output_ta.push_back(ta);
}

void
TAMakerPrescaleAlgorithm::configure(const nlohmann::json& config)
{
  TriggerActivityMaker::configure(config);
}

