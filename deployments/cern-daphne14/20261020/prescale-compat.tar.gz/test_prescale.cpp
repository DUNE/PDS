#include "triggeralgs/Prescale/TAMakerPrescaleAlgorithm.hpp"
#include <stdexcept>
#include <iostream>
using namespace triggeralgs;
void require(bool b) {if(!b)throw std::runtime_error("Prescale compatibility acceptance failed");}
int main() {
 TAMakerPrescaleAlgorithm maker; maker.configure({{"prescale",1}});
 TriggerPrimitive tp{};tp.detid=8;tp.time_start=100000;tp.samples_over_threshold=256;tp.samples_to_peak=200;tp.channel=804;tp.detid=8;tp.adc_integral=2000;tp.adc_peak=50;
 std::vector<TriggerActivity> out;maker(tp,out);require(out.size()==1);auto a=out.front();
 require(a.type==TriggerActivity::Type::kPDS && a.time_start==100000 && a.time_end==100256 && a.time_peak==100200 && a.time_activity==100000 && a.detid==8 && a.inputs.size()==1 && a.inputs[0].channel==804 && a.adc_integral==2000);
 maker.configure({{"prescale",10}});out.clear();
 for(int i=0;i<100;i++){tp.time_start=100000+i*1000;std::vector<TriggerActivity> next;maker(tp,next);out.insert(out.end(),next.begin(),next.end());}require(out.size()==10);
 TAMakerPrescaleAlgorithm tpc;out.clear();tp.detid=10;tp.time_start=100000;tpc(tp,out);require(out.size()==1 && out[0].type==TriggerActivity::Type::kTPC && out[0].time_end==108192 && out[0].time_peak==106400 && out[0].time_activity==0);
 tp.detid=8;tp.samples_over_threshold=0;bool rejected=false;try {std::vector<TriggerActivity> x;tpc(tp,x);}catch(const std::invalid_argument&){rejected=true;}require(rejected);
 std::cout<<"PDS type/timestamp/input preservation, prescale 10, TPC compatibility, invalid-input rejection: passed\n";
}
