#!/usr/bin/env python3
"""Read DAPHNE-15 CAL2 status; optionally configure its timing endpoint."""
import argparse
import json
import sys

from pds.core.runtime import DaphneBridge


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--require-ready', action='store_true')
    parser.add_argument('--configure-clock', action='store_true',
                        help='WRITE if needed: select endpoint clock, address 0x15, and pulse resets')
    args = parser.parse_args()
    bridge = DaphneBridge('tcp://np04-daphne-015.cern.ch:40001')
    try:
        clock_error = None
        initial = bridge.timing_status() if args.configure_clock else None
        if args.configure_clock and not (initial['clock_source'] == 'endpoint'
                and initial['clocks_locked'] and initial['endpoint_address'] == 0x15):
            high = bridge.high
            try:
                response = bridge._call(high.MT2_CONFIGURE_CLKS_REQ,
                    high.ConfigureCLKsRequest(id=0x15, ctrl_ep_clk=True,
                                              reset_MMCM1=True, reset_endpoint=True),
                    high.ConfigureCLKsResponse)
                print(response.message)
            except (RuntimeError, TimeoutError) as error:
                clock_error = str(error)
        status = bridge.timing_status()
        registers = dict(capability=bridge.read32(0xA0010F08),
                         selector=bridge.read32(0x88000034),
                         enabled=bridge.read32(0x94000020),
                         software_enabled=bridge.read32(0x94000024),
                         command_id=bridge.read32(0x94000028) & 255,
                         calibration_mask=bridge.read32(0xA0010F00),
                         pause_mask=bridge.read32(0xA0010F0C))
        print(json.dumps(dict(timing=status,
            registers={key: hex(value) for key, value in registers.items()},
            counters=bridge.counters(list(range(8)))), indent=2), flush=True)
        issues = []
        if clock_error:
            issues.append('Clock setup failed: ' + clock_error)
        if args.require_ready or args.configure_clock:
            if status['clock_source'] != 'endpoint' or not status['clocks_locked']:
                issues.append('Endpoint clock must be selected and locked')
            if status['endpoint_state'] != 8 or not status['timestamp_valid']:
                issues.append('Timing endpoint must reach state 8 with valid timestamps; align endpoint 0x15 through SC/CCM')
            if status['endpoint_address'] != 0x15:
                issues.append('DAPHNE-15 endpoint address must be 0x15')
        if args.require_ready:
            if registers['capability'] != 0x43414C32:
                issues.append('CAL2 firmware is required')
            if registers['selector'] != 2:
                issues.append('Selector 2 is required; run vst_prepare_board after DAQ conf')
            if registers['enabled'] & 255 != 255 or registers['command_id'] != 7:
                issues.append('All AFE0 channels must be enabled and timing command must be 7')
            if registers['software_enabled'] & 255:
                issues.append('AFE0 software triggers must be disabled')
            if registers['calibration_mask'] & 255 or registers['pause_mask'] & 255:
                issues.append('Reconcile existing AFE0 calibration/pause state before scanning')
        if issues:
            print('\n'.join(issues), file=sys.stderr)
            return 1
        return 0
    except (RuntimeError, TimeoutError, OSError) as error:
        print('DAPHNE status failed: ' + str(error), file=sys.stderr)
        return 1
    finally:
        bridge.close()


if __name__ == '__main__':
    sys.exit(main())
