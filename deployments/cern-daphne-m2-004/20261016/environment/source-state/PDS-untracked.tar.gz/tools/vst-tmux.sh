#!/usr/bin/env bash
# Prepare interactive CERN VST shells. Hardware operations are manual.
set -euo pipefail

session=pds-vst-daphne15-cal2
attach=1
usage() {
    cat <<'EOF'
Usage: bash tools/vst-tmux.sh [--session NAME] [--no-attach]

Run on the CERN control server as the DAQ account. Creates four windows:
daq, board, calibration, logs. Existing sessions are reused without changes.

Paths follow the beginner guide. Override these environment variables when
using another prepared area:
  DAPHNE_DAQ       Built DAQ workarea
  DAPHNE_CFG       Private OKS configuration directory
  DAPHNE_RECIPE    Site recipe containing DAPHNE status/setup helpers
  PDS_CHECKOUT    PDS source checkout
  PDS_VENV        Calibration Python virtual environment
  PDS_PROTOBUF_DIR Generated server Python schemas
  PDS_PLAN        Calibration plan JSON
  DAQ_INPUT       Directory containing this run's HDF5 files

The launcher sources environments and prints commands. It does not boot or
configure DAQ applications, write board registers, or launch calibration.
EOF
}
while (($#)); do
    case "$1" in
        --session) [[ $# -ge 2 ]] || { usage >&2; exit 2; }; session=$2; shift 2 ;;
        --no-attach) attach=0; shift ;;
        --help|-h) usage; exit 0 ;;
        *) usage >&2; exit 2 ;;
    esac
done
[[ "$session" =~ ^[a-zA-Z0-9_-]+$ ]] || {
    printf 'Session name must contain only letters, numbers, underscores or hyphens.\n' >&2
    exit 2
}
command -v tmux >/dev/null || { printf 'tmux is not installed.\n' >&2; exit 1; }
if tmux has-session -t "=$session" 2>/dev/null; then
    printf 'Existing session preserved: %s\n' "$session"
else
    export DAPHNE_DAQ=${DAPHNE_DAQ:-$HOME/daphne15-daq-20261008}
    export DAPHNE_CFG=${DAPHNE_CFG:-$DAPHNE_DAQ/config/daphne15-calibration}
    export DAPHNE_RECIPE=${DAPHNE_RECIPE:-$HOME/daphne15-recipe-20261008}
    export PDS_CHECKOUT=${PDS_CHECKOUT:-$DAPHNE_DAQ/control/PDS}
    export PDS_VENV=${PDS_VENV:-$DAPHNE_DAQ/control/venv}
    export PDS_PROTOBUF_DIR=${PDS_PROTOBUF_DIR:-$DAPHNE_DAQ/control/python}
    export PDS_PLAN=${PDS_PLAN:-$PDS_CHECKOUT/configs/calibration/vgain-afe0.json}
    export DAQ_INPUT=${DAQ_INPUT:-}
    for required in "$DAPHNE_DAQ/env.sh" "$DAPHNE_CFG/setup_db_path.sh" \
        "$DAPHNE_CFG/sessions/pds-vst-session.data.xml" \
        "$DAPHNE_RECIPE/daphne15_status.py" "$PDS_VENV/bin/activate" \
        "$PDS_CHECKOUT/tools/daphne15-status.py" \
        "$PDS_PROTOBUF_DIR/daphneV3_high_level_confs_pb2.py" "$PDS_PLAN"; do
        [[ -r "$required" ]] || { printf 'Missing setup file: %s\n' "$required" >&2; exit 1; }
    done
    rcdir=$(mktemp -d "${TMPDIR:-/tmp}/pds-vst-tmux.XXXXXXXX")
    for window in daq board calibration logs; do
        rcfile="$rcdir/$window.bashrc"
        {
            for variable in DAPHNE_DAQ DAPHNE_CFG DAPHNE_RECIPE PDS_CHECKOUT \
                PDS_VENV PDS_PROTOBUF_DIR PDS_PLAN DAQ_INPUT; do
                printf 'export %s=%q\n' "$variable" "${!variable}"
            done
            printf 'export VST_WINDOW=%q\n' "$window"
            printf 'export VST_SESSION=%q\n' "$session"
            cat <<'EOF'
# An existing tmux server can carry a different DAQ release in its environment.
# Load this workarea from a clean set of DAQ variables in each new shell.
for _vst_variable in "${!DBT_@}" "${!DUNEDAQ_@}"; do
    [[ -z "$_vst_variable" ]] || unset -v "$_vst_variable"
done
unset _vst_variable PYTHONPATH LD_LIBRARY_PATH CMAKE_PREFIX_PATH
export PATH=/usr/local/bin:/usr/bin:/bin
cd "$DAPHNE_DAQ" || return
if ! source ./env.sh; then
    printf 'DAQ environment failed to load. Check this window before continuing.\n' >&2
    return
fi
source "$DAPHNE_CFG/setup_db_path.sh" || return
if [[ "$VST_WINDOW" == board || "$VST_WINDOW" == calibration ]]; then
    source "$PDS_VENV/bin/activate" || return
    export PYTHONPATH="$PDS_PROTOBUF_DIR:$PDS_CHECKOUT/src${PYTHONPATH:+:$PYTHONPATH}"
fi
vst_daq() {
    source /nfs/home/np04daq/bin/web_proxy.sh -u || return
    drunc-unified-shell ssh-CERN-kafka.json \
        "$DAPHNE_CFG/sessions/pds-vst-session.data.xml" np02-session "$VST_SESSION"
}
_vst_pds() {
    PYTHONPATH="$PDS_PROTOBUF_DIR:$PDS_CHECKOUT/src${PYTHONPATH:+:$PYTHONPATH}" "$@"
}
daphne_status() { _vst_pds "$PDS_VENV/bin/python" "$PDS_CHECKOUT/tools/daphne15-status.py" "$@"; }
vst_prepare_board() {
    daphne_status --configure-clock || return
    scp "$DAPHNE_RECIPE/daphne15_runtime_prepare.py" \
        petalinux@np04-daphne-015:/tmp/daphne15_runtime_prepare.py || return
    ssh petalinux@np04-daphne-015 \
        'sudo -n python3 /tmp/daphne15_runtime_prepare.py --apply' || return
    daphne_status --require-ready
}
vst_help() { cat "$PDS_CHECKOUT/docs/cern-vst-commands.txt"; }
vst_plan() { _vst_pds "$PDS_VENV/bin/pds-calibrate" plan "$PDS_PLAN"; }
vst_calibrate() {
    if [[ $# != 2 || -z "$DAQ_INPUT" || ! -d "$DAQ_INPUT" ]]; then
        printf 'Usage: vst_calibrate NEW_RESULT_DIRECTORY NEW_JOURNAL_FILE\nSet DAQ_INPUT to this run\047s HDF5 directory first.\n' >&2
        return 2
    fi
    daphne_status --require-ready || return
    _vst_pds "$PDS_VENV/bin/pds-calibrate" run "$PDS_PLAN" --input-dir "$DAQ_INPUT" \
        --output-dir "$1" --journal "$2"
}
printf '\nVST window: %s\nDAQ area: %s\nConfiguration: %s\n' \
    "$VST_WINDOW" "$DAPHNE_DAQ" "$DAPHNE_CFG"
case "$VST_WINDOW" in
    daq) printf 'Run vst_daq when ready to open drunc. Then boot and conf manually.\n' ;;
    board) printf 'Read status: daphne_status\nStrict readiness check: daphne_status --require-ready\n' ;;
    calibration) printf 'Preview: vst_plan\nAfter timing readiness and DAQ acquisition: vst_calibrate NEW_RESULT_DIR NEW_JOURNAL\nInput: %s\n' "$DAQ_INPUT" ;;
    logs) printf 'Logs: %s/log\nHDF5 input: %s\n' "$DAPHNE_DAQ" "$DAQ_INPUT" ;;
esac
printf 'Switch windows: Ctrl+b then w. Detach: Ctrl+b then d.\n\n'
printf 'Show run commands: vst_help\n\n'
if [[ -d "$HOME/daq" && "$HOME/daq" -ef "$DAPHNE_DAQ" ]]; then
    cd -L "$HOME/daq"
fi
PS1="[VST:$VST_WINDOW] \u@\h:\W\$ "
EOF
        } > "$rcfile"
        # Export into each startup file rather than relying on an existing
        # tmux server's environment snapshot.
        printf -v shell_command '%q ' bash --noprofile --rcfile "$rcfile" -i
        if [[ "$window" == daq ]]; then
            tmux new-session -d -s "$session" -n "$window" -c "$DAPHNE_DAQ" "$shell_command"
        else
            tmux new-window -t "$session:" -n "$window" -c "$DAPHNE_DAQ" "$shell_command"
        fi
    done
    tmux set-option -t "$session" history-limit 20000
    tmux set-option -t "$session" prefix C-b
    tmux set-option -t "$session" @pds_vst_rcdir "$rcdir"
    tmux select-window -t "$session:daq"
    printf 'Prepared session: %s\n' "$session"
fi
printf 'Attach with: tmux attach -t %s\n' "$session"
if ((attach)); then
    if [[ -n "${TMUX:-}" ]]; then
        tmux switch-client -t "$session"
    else
        exec tmux attach-session -t "$session"
    fi
fi
