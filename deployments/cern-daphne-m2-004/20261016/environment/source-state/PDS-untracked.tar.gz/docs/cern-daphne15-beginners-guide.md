# Beginner guide to DAPHNE15 calibration at CERN

Use this guide to build the DAQ software, configure DAPHNE15, check its status,
and collect a vgain calibration scan after logging in as `np04daq` on
`np04-srv-017` or `np04-srv-024`.

The DAQ stays running while PDS changes the gain between calibration points.
You use **two terminals**: terminal A controls the DAQ; terminal B checks the
board and runs the calibration. Both terminals must use the same DAQ workarea.

**Acquisition is not yet qualified.** In the tmux test of 8 October 2026,
DAQ boot and configuration passed for all nine processes after correcting the
board server's ADC frame-monitor access. The Hermes service now waits for its
IPbus reply counter (`-c 1`, rather than the incorrectly parsed `-c true`).
GIB preflight passed, but endpoint `0x15` remained at state 6 without valid
timestamps after addressed alignment. The calibration helper refused to start;
no acquisition run or calibration data was collected. Resolve endpoint timing
before acquisition. The DPDK readout also crashed in `IfaceWrapper` destruction
after shutdown; its processes were verified stopped. This cleanup defect is
unresolved. The report is `~/calib/control/run-check-report.json`.

The tested board server is installed at
`/opt/daphne-server/cal2-vst-frame-monitor-20261008`, selected by
`/etc/systemd/system/daphne.service.d/85-vst-frame-monitor.conf`.
The Hermes correction is in `hermes.service.d/80-vst-reply-count.conf`.
The DAPHNE configuration reply timeout is 30000 ms.
## Before you start

You need a CERN AlmaLinux 9 DAQ server with CVMFS mounted, access to the shared
recipe below, and the approved SSH access to DAPHNE15 as `petalinux`.

Arrange ownership of the DAPHNE test session and reserve **GIB generator 1 and
timing command 7** through the site's slow-control and configuration management
system, called SC/CCM here. Use one control host for the scan.

The template uses these machines and devices:

| Role | Machine or setting |
| --- | --- |
| Your control terminal | `np04-srv-017` or `np04-srv-024` |
| Board control | `np04-daphne-015.cern.ch`, port `40001` |
| Board control IP | `10.73.137.16` |
| Ethernet readout | `np02-srv-001` |
| HDF5 data writer | `np04-srv-003` |
| Calibration selection | Firmware AFE 0, channels 0 through 7, source ID 800 |
| Timing endpoint address | `0x15`, which is decimal 21 |

AFE means analog front end: one group of eight channels. The scan uses firmware
AFE numbering. Other firmware AFEs do not necessarily share the same numbering
as physical board AFEs.

Paste `bash` blocks into the normal shell. Paste `text` blocks into the drunc
prompt only. If a command fails, stop at that step and use the troubleshooting
table near the end.

## Use the shared tmux session

The team session is owned by `np04daq` on `np04-srv-017`. After logging in there
as `np04daq`, attach with:

```bash
tmux attach -t pds-vst-daphne15-cal2
```

If the session has been closed, recreate it using the prepared team setup:

```bash
bash /nfs/home/np04daq/vst/daphne15-cal2-20261008/start-tmux.sh
```

The team setup uses the existing built DAQ area
`/nfs/home/marroyav/workareas/daq/daphne/pds-trigger-dev-20260930`, a private
calibration configuration, and a PDS Python environment under
`/nfs/home/np04daq/vst/daphne15-cal2-20261008`. The independent installation steps
below are available when you need your own workarea.

| Window | What to do |
| --- | --- |
| `daq` | This is terminal A. Run `vst_daq` to open drunc, then issue `boot` and `conf` manually. |
| `board` | This is terminal B for status checks. Run `daphne_status`; use `daphne_status --require-ready` before acquisition. |
| `calibration` | This is terminal B for scanning. Run `vst_plan` to preview the plan; after readiness and DAQ startup, run `vst_calibrate NEW_RESULT_DIR NEW_JOURNAL_FILE`. |
| `logs` | Inspect DAQ logs, HDF5 files, and the scan journal. |

Run `vst_help` in any window to print the
[short command reference](cern-vst-commands.txt). This full guide remains
available in `docs/cern-daphne15-beginners-guide.md`.

The launcher only prepares shells and their environments. It does not boot
applications, program the board, or start a scan. The timing and configuration
checks later in this guide still apply.

Press **Ctrl+b**, release both keys, then press **w** to choose a window.
Press **Ctrl+b**, release both keys, then press **d** to detach while leaving
the session running. You can attach again after an SSH disconnect. Agree who is
operating the DAQ before issuing commands in a shared session.

To use tmux with another prepared workarea, load that workarea's saved paths and
run [the launcher](../tools/vst-tmux.sh) from the PDS checkout containing it:

```bash
source "$HOME/daphne15-daq-20261008/calibration-paths.sh"
bash tools/vst-tmux.sh
```

Run the launcher from a fresh shell. It sources the selected DAQ environment
in every window and activates the calibration virtual environment only in the
board and calibration windows. Reusing an existing session leaves it unchanged.
The `daphne_status`, `vst_plan`, and `vst_calibrate` helpers select the PDS
Python environment themselves, so they also work in the logs window.
Set the endpoint clock and obtain timing alignment before DAQ `conf`.
After successful `conf`, `vst_prepare_board` checks the endpoint, copies and runs
the digital setup helper, and checks readiness. It stops on the first error.
`vst_calibrate` repeats the board readiness check before starting a scan.
Clock setup preserves an endpoint that already uses the locked endpoint clock
at address `0x15`. If it stops at state 6 after initial setup, have SC/CCM align
that endpoint and retry `vst_prepare_board`; the retry does not reset it again.

## First time only build the DAQ environment

In **terminal A**, start a fresh SSH login with no other DAQ environment sourced.
Confirm the account and machine:

```bash
whoami
hostname -f
```

Expect `np04daq` and either `np04-srv-017.cern.ch` or `np04-srv-024.cern.ch`.

Copy the site recipe to your own directory and build a new workarea:

```bash
export DAPHNE_RECIPE="$HOME/daphne15-recipe-20261008"
export DAPHNE_DAQ="$HOME/daphne15-daq-20261008"

cp -R \
  /nfs/home/marroyav/workareas/daq/daphne/operator-recipe-20261008 \
  "$DAPHNE_RECIPE"

source "$DAPHNE_RECIPE/build_daphne_env.sh" "$DAPHNE_DAQ" 8
```

The workarea directory must not already exist. Building can take time. Wait for
`DAPHNE environment built and loaded` before continuing.

The script uses DBT `v8.14.0` and DAQ release `fddaq-v5.6.2-a9-1`. It downloads,
builds, and checks pinned versions of `appmodel`, `daphnemodules`, `dpdklibs`,
`fddetdataformats`, `fdreadoutlibs`, `fdreadoutmodules`, `hermesmodules`, and
`rawdatautils`. The pins are listed in `build_daphne_env.sh`.

The shared recipe contains the CERN hardware database and firmware-specific
setup helpers. It is a required site input, separate from this PDS repository.
If the shared path is unavailable, obtain that recipe from the DAPHNE maintainer.

## First time only install PDS and the client schemas

Continue in **terminal A**:

```bash
cd "$DAPHNE_DAQ"
mkdir -p control/python

git clone --branch marroyav/calibration \
  https://github.com/DUNE/PDS.git control/PDS
git -C control/PDS checkout --detach \
  82fa12eeefef2d480fc23e869ad2c9c2bc54017b

git clone https://github.com/DUNE-DAQ/daphne-os.git control/daphne-os
git -C control/daphne-os checkout --detach \
  258cc46eb8973761fb59641f701c17cbea07f226

python3 -m venv --system-site-packages control/venv
source control/venv/bin/activate
python -m pip install -e 'control/PDS[runtime]' grpcio-tools

proto="$DAPHNE_DAQ/control/daphne-os/daphne-server/srcs/protobuf"
python -m grpc_tools.protoc \
  -I "$proto" \
  --python_out="$DAPHNE_DAQ/control/python" \
  "$proto/daphneV3_high_level_confs.proto" \
  "$proto/daphneV3_low_level_confs.proto"

export PYTHONPATH="$DAPHNE_DAQ/control/python${PYTHONPATH:+:$PYTHONPATH}"
```

The virtual environment holds the PDS Python dependencies. The generated
protobuf schemas tell the Python client how to talk to the board server.
These commands do not install or restart anything on DAPHNE15.

Check that the DAQ libraries and PDS dependencies can be imported:

```bash
python - <<'PY'
import zmq, hdf5libs, daqdataformats, timing.core, uhal
import fddetdataformats
import rawdatautils.unpack.daphneeth
import daphneV3_high_level_confs_pb2
assert fddetdataformats.DAPHNEEthFrame.sizeof() == 512
print("Calibration dependencies and 512-byte frame format OK")
PY

python control/PDS/tools/benchmark_unpacker.py
```

Expect the first command to print `Calibration dependencies and 512-byte frame
format OK`. The unpacker check should report `"verified": true`, `"frame_bytes":
512`, and `"samples_per_frame": 256`. It checks known samples and the compiled
decoder; it does not acquire data from hardware.

## Prepare the configuration for this run

Still in **terminal A**, create a private database and a new data directory:

```bash
export DAPHNE_CFG="$DAPHNE_DAQ/config/daphne15-calibration"
export DAQ_INPUT="/nfs/home/np04daq/calibration-data/daphne15-$(date -u +%Y%m%dT%H%M%SZ)"

mkdir -p "$DAQ_INPUT"

python "$DAPHNE_RECIPE/prepare_config.py" \
  "$DAPHNE_DAQ/config/tp-live-10ms-10Hz" \
  "$DAPHNE_CFG" \
  "$DAQ_INPUT"

cp "$DAPHNE_DAQ/control/PDS/configs/calibration/vgain-afe0.json" \
   "$DAPHNE_DAQ/control/vgain-afe0.json"

pds-calibrate plan "$DAPHNE_DAQ/control/vgain-afe0.json" \
  > "$DAPHNE_DAQ/control/vgain-plan.json"

declare -p DAPHNE_RECIPE DAPHNE_DAQ DAPHNE_CFG DAQ_INPUT \
  > "$DAPHNE_DAQ/calibration-paths.sh"
```

`calibration-paths.sh` saves the directory names so terminal B can load exactly
the same setup. The configuration destination must be new. On a later run,
choose another name, such as `daphne15-calibration-002`, for `DAPHNE_CFG`.

The generated database requests **2-second windows at 0.5 Hz** and writes one
event per HDF5 file. Closing each file makes it available to the calibration
collector. At a 62.5 MHz DAQ clock, two seconds is 125,000,000 timestamp ticks;
the helper also increases the trigger-record sequence limit to keep that window
whole. The database retains a buffer of 1,200,000 frames per stream and leaves
the disconnected physical link 1 disabled.

The calibration coordinator runs in your control terminal and reads the data
written by `np04-srv-003`. Confirm that this host can write to `$DAQ_INPUT` and
that your control terminal can read it.

**Before `conf`, review the analog settings and the scan values:**

```bash
cat "$DAPHNE_CFG/analog-settings-to-review.json"
cat "$DAPHNE_DAQ/control/vgain-afe0.json"
```

The helper preserves the template's analog settings. The DAQ `conf` command
applies board configuration, including bias and analog settings beyond the
eight channels selected for this scan. Check them against the connected sensors;
the saved summary is an overview, and the complete settings are in
`$DAPHNE_CFG/segments/pds-vst.data.xml`.

The example scan has 21 vgain DAC codes: 500 through 2500, in steps of 100.
These are DAC codes, not voltages. Review or edit the values before acquiring
data. After editing the JSON, rerun `pds-calibrate plan` to validate it.
The `plan` command does not change hardware.

Keep the template's Hermes transport identity unless the firmware transport is
being deliberately reconfigured. CERN's registered network MAC/IP values do
not automatically replace the identity used in captured DAQ packets.

## Terminal B source the calibration environment

Open a second SSH terminal as `np04daq` on the **same control host** used for
terminal A. Paste:

```bash
source "$HOME/daphne15-daq-20261008/calibration-paths.sh"
cd "$DAPHNE_DAQ"
source env.sh
source "$DAPHNE_CFG/setup_db_path.sh"
source control/venv/bin/activate
export PYTHONPATH="$DAPHNE_DAQ/control/python${PYTHONPATH:+:$PYTHONPATH}"

python "$DAPHNE_RECIPE/daphne15_status.py"
```

This last command is read-only. It prints the timing state, calibration
registers, and channel counters. A normal return from this status command alone
does not mean the board is ready; the strict readiness check comes below.

## Terminal B make timing ready

Have SC/CCM align DAPHNE15 endpoint **0x15** with the GIB timing master.
The master must broadcast valid timestamps, and generator 1 and command 7 must
be reserved and inactive before the calibration coordinator starts.

After the master and timing route are ready, configure the board endpoint:

```bash
python "$DAPHNE_RECIPE/daphne15_status.py" --configure-clock
```

This command **writes hardware settings when needed**: it selects the endpoint
clock, sets address 0x15, and pulses resets. If that clock and address are already
selected and locked, retries preserve alignment. It does not align the master.
If it reports a timeout or the endpoint remains at state 6, stop here. Resolving
the timing route requires the site timing controls; repeating the scan command
will not fix it.


## Terminal A boot and configure the DAQ

Leave the calibration virtual environment before launching drunc:

```bash
deactivate
cd "$DAPHNE_DAQ"
source env.sh
source "$DAPHNE_CFG/setup_db_path.sh"
source /nfs/home/np04daq/bin/web_proxy.sh -u

drunc-unified-shell ssh-CERN-kafka.json \
  "$DAPHNE_CFG/sessions/pds-vst-session.data.xml" \
  np02-session daphne15-calib
```

You should now see the `drunc-unified-shell` prompt. Enter these commands one
at a time, waiting for each to finish:

```text
boot
conf
```

`boot` launches the applications. `conf` configures the DAQ, the board, and
Hermes transport. Check the command report for successful transitions before
continuing. Leave terminal A open at the drunc prompt.

Keep `np02-session` as the configuration ID: it is the ID stored in the supplied
database, even though this procedure controls a board at NP04. `daphne15-calib`
is the runtime session name.

The pinned appmodel and Hermes wrappers configure both declared physical links
and start only the enabled link. A separate manual `links.py` setup is not part
of this procedure.

## Terminal B prepare the board after successful DAQ configuration

Once timing and DAQ configuration are ready, copy the firmware-specific digital setup helper to the
board and apply it:

```bash
scp "$DAPHNE_RECIPE/daphne15_runtime_prepare.py" \
  petalinux@np04-daphne-015:/tmp/daphne15_runtime_prepare.py

ssh petalinux@np04-daphne-015 \
  'sudo -n python3 /tmp/daphne15_runtime_prepare.py --apply'

python "$DAPHNE_RECIPE/daphne15_status.py" --require-ready
```

Use the approved board SSH credentials and host key. The helper checks firmware
identity `93e0579`, CAL2 support, timing readiness, and the existing calibration
state before writing. It enables only firmware channels 0 through 7, selects
mode 2 and command 7, and disables software-trigger admission and continuation.
It does not program analog DACs or generate timing commands.

The readiness check must exit successfully. Expect these values:

| Status field | Expected value |
| --- | --- |
| `clock_source` | `endpoint` |
| `clocks_locked` | `true` |
| `endpoint_state` | `8` |
| `timestamp_valid` | `true` |
| `endpoint_address` | `21` |
| `capability` | `0x43414c32` |
| `selector` | `0x2` |
| `enabled` | `0xff` after the digital setup |
| `software_enabled` | `0x0` |
| `command_id` | `0x7` |
| `calibration_mask` and `pause_mask` | `0x0` before the first scan |

Do the digital setup **after** `conf`. If you reconfigure the DAQ, repeat the
board preparation and readiness check before acquisition.

## Terminal A start one DAQ run

Return to the drunc prompt in **terminal A**:

```text
start-run --run-type TEST
```

Wait for a successful transition to acquisition. This sequence starts the
applications and enables the DAQ readout triggers; it skips the already
completed boot/configuration transitions.

In **terminal B**, inspect the input directory:

```bash
ls -lh "$DAQ_INPUT"
```

You need fresh, closed files ending in `.hdf5`. Files ending in `.writing` are
still open. The collector checks for a recent file with source ID 800 and an
exact 2-second window before programming scan settings. If the files are missing,
check readout, transport, timestamp flow, and the writer before proceeding.

## Terminal B launch the calibration

Choose new result names, then run:

```bash
export CAL_RESULTS="$DAPHNE_DAQ/control/vgain-results-001"
export CAL_JOURNAL="$DAPHNE_DAQ/control/vgain-results-001.jsonl"

pds-calibrate run "$DAPHNE_DAQ/control/vgain-afe0.json" \
  --input-dir "$DAQ_INPUT" \
  --output-dir "$CAL_RESULTS" \
  --journal "$CAL_JOURNAL"
```

Do not create `CAL_RESULTS` beforehand. The coordinator creates it and refuses
to overwrite an existing dataset or journal. The DAQ must stay running for the
whole scan; it is not restarted between gain values.

The two rates have different jobs:

| Rate | What it controls |
| --- | --- |
| DAQ 0.5 Hz | How often the DAQ requests a 2-second readout window |
| GIB requested 6000 Hz | How often DAPHNE captures a timing-triggered waveform |

The measured GIB rate for this request is about **5812.872 Hz**, giving about
11,626 waveforms per selected channel in a 2-second window. The coordinator
records the actual timing rate. Waiting for a stable window and file closure
adds time between points.

To watch progress, use another sourced shell or inspect the journal after the
command returns:

```bash
tail -n 10 "$CAL_JOURNAL"
```

Each accepted point has a `step_complete` entry and a pair of files:

```text
step-000.bin
step-000.json
step-001.bin
step-001.json
...
```

The `.bin` file contains packed 512-byte waveforms. The `.json` file records the
settings, selected window, counts, and checksum. Only points with a
`step_complete` receipt are accepted. A successful full scan ends with
`scan_complete` in the journal.

## Terminal A stop the DAQ

After the calibration finishes, return to **terminal A**:

```text
stop-run
shutdown
```

Wait for each command to finish. Keep the HDF5 data, result files, plan, and
journal together for later analysis.

The supplied plan leaves AFE 0 **paused** with the last gain setting retained.
It does not restore previous analog settings or return to physics acquisition.
Before another scan or a physics run, have SC/CCM explicitly apply the chosen
operating state and reconcile the AFE's calibration/pause state.

If you need to interrupt a scan, use **Ctrl+C in terminal B**. The coordinator
attempts to stop its timing generator and pause the affected AFE. Check the
journal and board/timing state afterward, then stop the DAQ in terminal A.
Loss of the control host or force-killing a process can prevent that cleanup;
SC/CCM must reconcile the hardware before restarting.

Keep the firmware and board server services running throughout acquisition.
Restarting the board runtime can reload gateware and reset its operating state.
After such a restart, reapply the configuration and readiness checks.

## On the next login

Do not repeat the build, clones, or installation if the workarea is intact.

In **terminal A**, load the saved paths and the environments needed to prepare
the next configuration and validate its plan:

```bash
source "$HOME/daphne15-daq-20261008/calibration-paths.sh"
cd "$DAPHNE_DAQ"
source env.sh
source "$DAPHNE_CFG/setup_db_path.sh"
source control/venv/bin/activate
export PYTHONPATH="$DAPHNE_DAQ/control/python${PYTHONPATH:+:$PYTHONPATH}"
```

For a **new run**, choose a new `DAPHNE_CFG` name and data directory, then repeat
the configuration preparation and save the updated paths. Do this before
opening drunc; changing a shell variable does not update a running DAQ writer.
Deactivate the virtual environment before launching drunc, as shown in the
boot and configure section.

In **terminal B**, repeat the calibration-environment sourcing section. Every
new shell needs its environment sourced, even when the software is already
installed. Recheck timing and board state for each acquisition session.

## Troubleshooting

| What you see | What to do |
| --- | --- |
| Workarea or configuration destination already exists | Reuse the existing workarea on later logins; give a new configuration a new name. Preserve existing results. |
| Shared recipe path does not exist | Obtain the CERN hardware recipe from the DAPHNE maintainer. PDS alone does not contain that site's OKS database. |
| `No module named zmq` | In terminal B, activate `control/venv` and check that the `PDS[runtime]` installation succeeded. |
| `No module named daphneV3_high_level_confs_pb2` | Generate the client schemas and add `control/python` to `PYTHONPATH` as shown above. |
| Missing `timing`, `uhal`, `hdf5libs`, or `daqdataformats` | Source the DAQ workarea from its own directory before activating the calibration virtual environment. |
| Frame size is 968 rather than 512 | You have an incompatible DAQ environment. Start a fresh login and source the pinned workarea. |
| Decoder compatibility check fails | Rebuild `rawdatautils` against the matching `fddetdataformats`; changing Python imports alone does not fix the compiled decoder. |
| Board request times out | Check the hostname, CERN connectivity, and board service status through the approved board access. The control port is 40001; allow 30000 ms for frontend configuration and its ADC alignment. |
| SSH access or noninteractive sudo fails | Use the approved board account/key and arrange its required access with the maintainer. |
| Wrong identity or missing CAL2 | Confirm DAPHNE15 is running the prepared `93e0579` profile. This helper is specific to that build. |
| Readout crashes in `IfaceWrapper` destruction after shutdown | Preserve the readout log and verify this session has no processes left before reusing the NIC. This defect remains unresolved in the tested workarea. |
| Local clock, endpoint state 6, or invalid timestamps | Resolve GIB/endpoint alignment through SC/CCM. Do not launch the scan until the strict readiness check passes. |
| Generator or matching command already active | Reconcile timing ownership through SC/CCM before the scan. |
| Existing calibration/pause state | A previous scan may have left AFE 0 paused. Apply an explicit operating state through SC/CCM before retrying. |
| No fresh closed DAQ file | Check acquisition and writer status, source 800, the output directory, and file closure. `.writing` files are not read. |
| DAQ window mismatch | Use the private calibration database, then perform a fresh boot/configuration. The original template has 10 ms windows. |
| Result directory or journal already exists | Choose a new suffix, such as `002`, for both result names. An unsuccessful scan can also leave a journal. |
| Waveform coverage, continuity, fragment status, or capture-counter failure | Preserve the journal and data. Check timing and transport; files from a failed point are not accepted results. |

## Further reading

- [Calibration scan behavior and data format](calibration-scans.md)
- [Runtime calibration controls](runtime-calibration.md)
- [SiPM calibration matrices](sipm-matrices.md)
- [Measured timing rates](measurements/timing-rate-20261005/README.md)

Use `pds-calibrate` for this continuous workflow. The older `pds-run run --mode
calibrun` and run-per-point scan commands are deprecated.
