#!/bin/sh
set -eu
test "$(cat /sys/class/net/end0/address)" = '00:0a:35:24:05:30'
# This site's management module is FS SFP1G-SX-85, 1000BASE-SX.
# Preserve the live GEM configuration except SGMII AN semantics (bit 27).
config=$(devmem 0xff0b0004 32)
devmem 0xff0b0004 32 "$(printf '0x%08x' "$((config & ~0x08000000))")"
devmem 0xff0b0210 32 0x00000020
control=$(devmem 0xff0b0200 32)
devmem 0xff0b0200 32 "$(printf '0x%08x' "$((control | 0x1200))")"
echo 'DAPHNE004 management: optical 1000BASE-X, full-duplex advertisement, AN restarted'
