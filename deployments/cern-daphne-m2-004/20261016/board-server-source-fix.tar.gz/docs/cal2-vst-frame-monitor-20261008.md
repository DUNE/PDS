# DAPHNE-15 CAL2 VST configuration fix

The CAL2 compact-v4 firmware does not implement the legacy spy-buffer frame
clock lane at 0x90008000. The old server dereferenced that address during
ConfigureFE ADC alignment and exited with SIGBUS. For packet protocol 4,
SpyBuffer::getFrameClock now reads the firmware frame monitor at 0x88000038 /
0x8800003C. It checks capability 0xAFE1, AFE selection and snapshot completion,
with a bounded timeout; it does not fall back to the absent spy buffer.
The legacy path is retained for other packet protocols.

The Hermes service option `-c true` was parsed as false by its stream-based bool
parser, disabling the wait for a completed IPbus reply. Service templates now
use `-c 1`. This addresses the observed intermittent zero reply header.

The native frame-monitor tests cover missing capability, busy monitor, wrong
AFE, stopped capture timeout, request format and successful snapshot readback.
An ARM64 Release server build was deployed to DAPHNE-15. All nine DAQ processes
passed boot and configuration. End-to-end acquisition remains unqualified:
timing endpoint 0x15 remains at state 6 without valid timestamps, including
after addressed GIB alignment. No acquisition run has started. The DPDK readout
also crashed during IfaceWrapper destruction after orderly scrap/shutdown; that
separate DAQ cleanup defect is unresolved. Session processes were verified stopped.

Installed server: `/opt/daphne-server/cal2-vst-frame-monitor-20261008`.
ELF SHA256: `6b786fa74f6c73e8f23af957bd5f55746b9a5774bc7913c0a37eef439505f82c`.
Base server source commit: `258cc46`; this fix is on local branch
`marroyav/cal2-vst-frame-monitor-20261008`.

Board service overrides are `daphne.service.d/85-vst-frame-monitor.conf` and
`hermes.service.d/80-vst-reply-count.conf` under `/etc/systemd/system`.
Temporary diagnostic overrides that skipped alignment or traced SIGBUS were
removed. To roll back, stop DAQ acquisition first, remove these two overrides,
reload systemd, restart Hermes, then start DAPHNE. The prior server package and
its `80-cal2-server.conf` override were preserved. Recheck configuration and
timing after any service restart; frontend quiescing resets digital state.

Shared session and logs on np04-srv-017, owned by np04daq:
`pds-vst-daphne15-cal2`, `~/calib/control/run-check-report.json`,
`~/calib/control/frame-monitor-conf-transcript.txt`.
