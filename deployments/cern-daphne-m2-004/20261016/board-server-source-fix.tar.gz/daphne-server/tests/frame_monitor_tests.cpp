#include "server_controller/frame_monitor.hpp"
#include <cassert>
#include <deque>
#include <utility>
#include <vector>

struct Monitor : daphne_sc::Mmio32 {
  std::deque<uint32_t> statuses;
  std::vector<std::pair<uint64_t,uint32_t>> writes;
  uint32_t read32(uint64_t address) override {
    if (address == 0x8800003C) return 0x00FF00FF;
    const auto value = statuses.front();
    if (statuses.size() > 1) statuses.pop_front();
    return value;
  }
  void write32(uint64_t address, uint32_t value) override { writes.emplace_back(address,value); }
};

template<class E, class F> void fails(F fn) {
  bool caught=false;
  try { fn(); } catch (const E&) { caught=true; }
  assert(caught);
}

int main() {
  Monitor ready; ready.statuses={0xAFE10000,0xAFE10009,0xAFE1000A};
  assert(daphne_sc::read_frame_monitor(ready,2)==0x00FF00FF);
  assert((ready.writes==std::vector<std::pair<uint64_t,uint32_t>>{{0x88000038,0x102}}));
  Monitor missing; missing.statuses={0};
  fails<std::runtime_error>([&]{daphne_sc::read_frame_monitor(missing,0);});
  assert(missing.writes.empty());
  Monitor busy; busy.statuses={0xAFE10001};
  fails<std::runtime_error>([&]{daphne_sc::read_frame_monitor(busy,0);});
  assert(busy.writes.empty());
  Monitor stopped; stopped.statuses={0xAFE10000,0xAFE10001};
  fails<std::runtime_error>([&]{daphne_sc::read_frame_monitor(stopped,0,std::chrono::milliseconds(0));});
  Monitor wrong; wrong.statuses={0xAFE10000,0xAFE10002};
  fails<std::runtime_error>([&]{daphne_sc::read_frame_monitor(wrong,2,std::chrono::milliseconds(0));});
  Monitor invalid; invalid.statuses={0xAFE10000};
  fails<std::invalid_argument>([&]{daphne_sc::read_frame_monitor(invalid,5);});
  assert(invalid.writes.empty());
}
