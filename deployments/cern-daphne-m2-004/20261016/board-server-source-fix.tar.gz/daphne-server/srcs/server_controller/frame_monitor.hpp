#pragma once

#include <chrono>
#include <stdexcept>
#include <thread>

#include "server_controller/gateware.hpp"

namespace daphne_sc {

inline uint32_t read_frame_monitor(Mmio32& mmio, uint32_t afe,
                                  std::chrono::milliseconds timeout = std::chrono::milliseconds(20)) {
  constexpr uint64_t control = 0x88000038;
  constexpr uint64_t data = 0x8800003C;
  if (afe > 4) throw std::invalid_argument("Frame-monitor AFE must be 0..4");
  const uint32_t initial = mmio.read32(control);
  if ((initial >> 16) != 0xAFE1) throw std::runtime_error("Frame-monitor capability is missing");
  if (initial & 1) throw std::runtime_error("Frame monitor is busy");
  mmio.write32(control, 0x100 | afe);
  const auto deadline = std::chrono::steady_clock::now() + timeout;
  for (;;) {
    const uint32_t status = mmio.read32(control);
    if ((status >> 16) != 0xAFE1) throw std::runtime_error("Frame-monitor capability changed");
    if ((status & 3) == 2 && ((status >> 2) & 7) == afe) return mmio.read32(data);
    if (std::chrono::steady_clock::now() >= deadline)
      throw std::runtime_error("Frame-monitor snapshot timed out");
    std::this_thread::sleep_for(std::chrono::microseconds(50));
  }
}

}  // namespace daphne_sc
